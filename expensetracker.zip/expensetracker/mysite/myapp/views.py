from django.shortcuts import render,redirect
from .forms import ExpenseForm
from .models import Expense
from django.db.models import Sum
from django.db.models.functions import TruncDate
import datetime
# Create your views here.
def index(request):
    if request.method=="POST":
        expense=ExpenseForm(request.POST)
        if expense.is_valid():
            expense.save()

    #GET REQUEST
    expenses=Expense.objects.all()
    total_expenses=expenses.aggregate(Sum("amounts"))['amounts__sum']
    print(total_expenses)
    expense_form=ExpenseForm()

    #calculating 365 days expenses
    last_year=datetime.date.today() - datetime.timedelta(days=365)
    data=Expense.objects.filter(date__gt=last_year)
    yearly_sum=data.aggregate(Sum("amounts"))['amounts__sum']


    #Monthly sum
    last_month = datetime.date.today() - datetime.timedelta(days=30)
    data = Expense.objects.filter(date__gt=last_month)
    monthly_sum = data.aggregate(Sum("amounts"))['amounts__sum']

    # Weekly sum
    last_week = datetime.date.today() - datetime.timedelta(days=7)
    data = Expense.objects.filter(date__gt=last_week)
    weekly_sum = data.aggregate(Sum("amounts"))['amounts__sum']

   #calculating daily sum

    daily_sums = (
        Expense.objects
        .annotate(day=TruncDate('date'))  # sirf date part nikalo
        .values('day')  # group by day
        .order_by('day')  # order by day
        .annotate(sum=Sum('amounts'))  # sum of amounts field
    )
    #Sum per category
    categorical_sum=Expense.objects.filter().values('category').annotate(sum=Sum('amounts'))



    return render(request,'myapp/index.html',{'expense_form':expense_form,'expenses':expenses,'total_expenses':total_expenses,'yearly_sum':yearly_sum,'monthly_sum':monthly_sum,'weekly_sum':weekly_sum,'daily_sums':daily_sums,'categorical_sum':categorical_sum})

def edit(request,id):
    expense=Expense.objects.get(id=id)
    expense_form=ExpenseForm(instance=expense)
    if request.method=="POST":
        form=ExpenseForm(request.POST,instance=expense)
        if form.is_valid():
            form.save()
            return redirect('index')
    return render(request,'myapp/edit.html',{'expense_form':expense_form})

def delete(request,id):
    if request.method=="POST":
        expense=Expense.objects.get(id=id)
        expense.delete()
    return redirect('index')